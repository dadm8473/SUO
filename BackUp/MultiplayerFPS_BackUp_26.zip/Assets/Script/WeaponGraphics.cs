﻿using UnityEngine;

public class WeaponGraphics : MonoBehaviour {

    public ParticleSystem muzzleFlash;
    public GameObject hitEffectPrefab;
	
}
