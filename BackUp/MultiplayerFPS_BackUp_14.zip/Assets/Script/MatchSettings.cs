﻿[System.Serializable]
public class MatchSetting{

    public float respawnTime = 3f;

}
